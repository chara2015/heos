package xyz.nikitacartes.heos.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import xyz.nikitacartes.heos.integrations.Permissions;
import xyz.nikitacartes.heos.storage.PlayerEntryV1;
import xyz.nikitacartes.heos.interfaces.PlayerAuth;

import static net.minecraft.server.command.CommandManager.literal;
import static xyz.nikitacartes.heos.Heos.getUnixZero;
import static xyz.nikitacartes.heos.Heos.langConfig;

public class LogoutCommand {

    public static void registerCommand(CommandDispatcher<ServerCommandSource> dispatcher) {
        // Registering the "/logout" command
        dispatcher.register(literal("logout")
                .requires(Permissions.require("Heos.commands.logout", true))
                .executes(ctx -> logout(ctx.getSource())) // Tries to de-authenticate the user
        );
    }

    private static int logout(ServerCommandSource serverCommandSource) throws CommandSyntaxException {
        ServerPlayerEntity player = serverCommandSource.getPlayerOrThrow();
        PlayerAuth playerAuth = (PlayerAuth) player;

        if (playerAuth.Heos$isAuthenticated() && !playerAuth.Heos$canSkipAuth()) {
            // player.getServer().getPlayerManager().sendToAll(new PlayerListS2CPacket(PlayerListS2CPacket.Action.REMOVE_PLAYER, player));
            playerAuth.Heos$setAuthenticated(false);

            PlayerEntryV1 playerData = playerAuth.Heos$getPlayerEntryV1();
            playerData.lastAuthenticatedDate = getUnixZero();
            playerData.update();

            langConfig.successfulLogout.send(serverCommandSource);
        } else {
            langConfig.cannotLogout.send(serverCommandSource);
        }
        return 1;
    }
}
