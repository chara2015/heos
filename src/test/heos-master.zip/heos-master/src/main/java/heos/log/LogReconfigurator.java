package heos.log;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.ConfigurationFactory;
import org.apache.logging.log4j.core.impl.Log4jContextFactory;
import org.apache.logging.log4j.spi.LoggerContextFactory;

import java.io.IOException;
import java.net.URI;
import java.util.List;

public class LogReconfigurator {
    private static final Logger LOGGER = LogManager.getLogger("Heos Log");
    
    public static void reconfigureWithUri(URI newConfigUri) throws UnsupportedOperationException, IOException {
        LoggerContextFactory factory = LogManager.getFactory();
        reconfigureLoggerContextFactoryWithUri(factory, newConfigUri);
    }

    public static void reconfigureLoggerContextFactoryWithUri(LoggerContextFactory factory, URI newConfigUri)
            throws UnsupportedOperationException, IOException {
        if (factory instanceof Log4jContextFactory) {
            reconfigureLog4jContextFactoryWithUri((Log4jContextFactory) factory, newConfigUri);
        } else {
            throw new UnsupportedOperationException(
                    String.format("Expected LoggerContextFactory to be Log4jContextFactory, but it was %s instead!",
                            factory.getClass().getSimpleName()));
        }
    }

    public static void reconfigureLog4jContextFactoryWithUri(Log4jContextFactory factory,
                                                              URI newConfigUri) throws IOException {
        List<LoggerContext> contexts = factory.getSelector().getLoggerContexts();

        LOGGER.debug("Reconfiguring {} LoggerContexts:", contexts.size());

        boolean anySucceeded = false;

        for (LoggerContext context : contexts) {
            if (reconfigureLoggerContextWithUri(context, newConfigUri)) {
                anySucceeded = true;
                LOGGER.debug("Reconfigured LoggerContext[{}] ({})", context.getName(), context);
            } else {
                LOGGER.warn(
                        "Could not reconfigure LoggerContext[{}] ({})! Some log messages may use the incorrect config.",
                        context.getName(), context);
            }
        }

        if (!anySucceeded) {
            throw new IOException(String.format(
                    "The config URI %s failed configuration with every available LoggerContext!", newConfigUri));
        }
    }

    public static boolean reconfigureLoggerContextWithUri(LoggerContext context, URI newConfigUri) {
        Configuration configuration = ConfigurationFactory.getInstance().getConfiguration(context, context.getName(),
                newConfigUri);
        if (configuration != null) {
            context.start(configuration);
            return true;
        }
        return false;
    }
}

