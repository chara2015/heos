package xyz.nikitacartes.heos.mixin;

import net.minecraft.advancement.PlayerAdvancementTracker;
import net.minecraft.server.ServerAdvancementLoader;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Uuids;
import xyz.nikitacartes.heos.interfaces.PlayerAuth;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.nikitacartes.heos.utils.StoneCutterUtils;

import static xyz.nikitacartes.heos.Heos.serverProp;
import static xyz.nikitacartes.heos.Heos.extendedConfig;

import java.nio.file.Path;

@Mixin(PlayerAdvancementTracker.class)
public class PlayerAdvancementTrackerMixin {

    @Mutable
    @Shadow
    @Final
    private Path filePath;

    @Shadow
    private ServerPlayerEntity owner;

    @Inject(method = "load(Lnet/minecraft/server/ServerAdvancementLoader;)V", at = @At("HEAD"))
    private void startMigratingOfflineAdvancements(ServerAdvancementLoader advancementLoader, CallbackInfo ci) {
        if (Boolean.parseBoolean(serverProp.getProperty("online-mode")) && !extendedConfig.forcedOfflineUuid && ((PlayerAuth) this.owner).Heos$isUsingMojangAccount() && !this.filePath.toFile().isFile()) {
            // Migrate
            String playername = StoneCutterUtils.getName(owner.getGameProfile());
            this.filePath = this.filePath.getParent().resolve(Uuids.getOfflinePlayerUuid(playername) + ".json");
        }
    }

    @Inject(method = "load(Lnet/minecraft/server/ServerAdvancementLoader;)V", at = @At("TAIL"))
    private void endMigratingOfflineAdvancements(ServerAdvancementLoader advancementLoader, CallbackInfo ci) {
        if (Boolean.parseBoolean(serverProp.getProperty("online-mode")) && !extendedConfig.forcedOfflineUuid && ((PlayerAuth) this.owner).Heos$isUsingMojangAccount()) {
            // Changes the file name to use online UUID
            this.filePath = this.filePath.getParent().resolve(owner.getUuid() + ".json");
        }
    }
}
