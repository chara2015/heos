package xyz.nikitacartes.heos.config;

//? if >= 1.21.9 {
import net.minecraft.server.PlayerConfigEntry;
//?}
import com.mojang.authlib.GameProfile;
import net.minecraft.util.UserCache;
import xyz.nikitacartes.heos.Heos;
import xyz.nikitacartes.heos.config.deprecated.AuthConfig;
import xyz.nikitacartes.heos.storage.database.*;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import static xyz.nikitacartes.heos.Heos.gameDirectory;
import static xyz.nikitacartes.heos.utils.HeosLogger.LogError;
import static xyz.nikitacartes.heos.utils.HeosLogger.LogInfo;
import static xyz.nikitacartes.heos.config.LangConfigV1.TranslatableText;

public class ConfigMigration {

    public static void migrateFromV0() {
        AuthConfig oldConfig = AuthConfig.load(new File(gameDirectory + "/mods/Heos/config.json"));
        if (oldConfig == null) {
            return;
        }

        LogInfo("Migrating config from v0 to v1");

        Heos.config = new MainConfigV1();
        Heos.config.premiumAutoLogin = oldConfig.main.premiumAutologin;
        Heos.config.floodgateAutoLogin = oldConfig.main.floodgateAutologin;
        Heos.config.maxLoginTries = oldConfig.main.maxLoginTries;
        Heos.config.kickTimeout = oldConfig.main.kickTime;
        Heos.config.resetLoginAttemptsTimeout = oldConfig.experimental.resetLoginAttemptsTime;
        Heos.config.sessionTimeout = oldConfig.main.sessionTimeoutTime;
        Heos.config.enableGlobalPassword = oldConfig.main.enableGlobalPassword;
        Heos.config.hidePlayerCoords = oldConfig.main.spawnOnJoin;
        Heos.config.debug = oldConfig.experimental.debugMode;
        Heos.config.configVersion = 1;
        Heos.config.worldSpawn.dimension = notNull(oldConfig.worldSpawn.dimension);
        Heos.config.worldSpawn.x = oldConfig.worldSpawn.x;
        Heos.config.worldSpawn.y = oldConfig.worldSpawn.y;
        Heos.config.worldSpawn.z = oldConfig.worldSpawn.z;
        Heos.config.worldSpawn.yaw = oldConfig.worldSpawn.yaw;
        Heos.config.worldSpawn.pitch = oldConfig.worldSpawn.pitch;
        Heos.config.save();

        Heos.extendedConfig = new ExtendedConfigV1();
        Heos.extendedConfig.allowChat = oldConfig.experimental.allowChat;
        Heos.extendedConfig.allowCommands = oldConfig.experimental.allowCommands;
        Heos.extendedConfig.allowedCommands = notNull(oldConfig.experimental.allowedCommands);
        Heos.extendedConfig.allowMovement = oldConfig.experimental.allowMovement;
        Heos.extendedConfig.allowBlockInteraction = oldConfig.experimental.allowBlockUse;
        Heos.extendedConfig.allowEntityInteraction = oldConfig.main.allowEntityInteract;
        Heos.extendedConfig.allowBlockBreaking = oldConfig.experimental.allowBlockPunch;
        Heos.extendedConfig.allowEntityAttacking = oldConfig.experimental.allowEntityPunch;
        Heos.extendedConfig.allowItemDropping = oldConfig.experimental.allowItemDrop;
        Heos.extendedConfig.allowItemMoving = oldConfig.experimental.allowItemMoving;
        Heos.extendedConfig.allowItemUsing = oldConfig.experimental.allowItemUse;
        Heos.extendedConfig.playerInvulnerable = oldConfig.experimental.playerInvulnerable;
        Heos.extendedConfig.playerIgnored = oldConfig.experimental.playerInvisible;
        Heos.extendedConfig.teleportationTimeoutMs = oldConfig.experimental.teleportationTimeoutInMs;
        Heos.extendedConfig.aliases = new ExtendedConfigV1.Aliases(oldConfig.experimental.enableAliases, oldConfig.experimental.enableAliases);
        Heos.extendedConfig.tryPortalRescue = oldConfig.main.tryPortalRescue;
        Heos.extendedConfig.minPasswordLength = oldConfig.main.minPasswordChars;
        Heos.extendedConfig.maxPasswordLength = oldConfig.main.maxPasswordChars;
        Heos.extendedConfig.usernameRegexp = notNull(oldConfig.main.usernameRegex);
        Heos.extendedConfig.floodgateBypassRegex = oldConfig.experimental.floodgateBypassUsernameRegex;
        Heos.extendedConfig.preventAnotherLocationKick = oldConfig.experimental.preventAnotherLocationKick;
        Heos.extendedConfig.forcedOfflineUuid = oldConfig.experimental.forcedOfflineUuids;
        Heos.extendedConfig.skipAllAuthChecks = oldConfig.experimental.skipAllAuthChecks;
        Heos.extendedConfig.save();

        Heos.langConfig = new LangConfigV1();
        Heos.langConfig.enableServerSideTranslation = oldConfig.experimental.enableServerSideTranslation;
        Heos.langConfig.enterPassword = new TranslatableText("text.heos.enterPassword", notNull(oldConfig.lang.enterPassword));
        Heos.langConfig.enterNewPassword = new TranslatableText("text.heos.enterNewPassword", notNull(oldConfig.lang.enterNewPassword));
        Heos.langConfig.wrongPassword = new TranslatableText("text.heos.wrongPassword", notNull(oldConfig.lang.wrongPassword));
        Heos.langConfig.matchPassword = new TranslatableText("text.heos.matchPassword", notNull(oldConfig.lang.matchPassword));
        Heos.langConfig.passwordUpdated = new TranslatableText("text.heos.passwordUpdated", notNull(oldConfig.lang.passwordUpdated));
        Heos.langConfig.loginRequired = new TranslatableText("text.heos.loginRequired", notNull(oldConfig.lang.loginRequired));
        Heos.langConfig.loginTriesExceeded = new TranslatableText("text.heos.loginTriesExceeded", notNull(oldConfig.lang.loginTriesExceeded));
        Heos.langConfig.globalPasswordSet = new TranslatableText("text.heos.globalPasswordSet", notNull(oldConfig.lang.globalPasswordSet));
        Heos.langConfig.cannotChangePassword = new TranslatableText("text.heos.cannotChangePassword", notNull(oldConfig.lang.cannotChangePassword));
        Heos.langConfig.cannotUnregister = new TranslatableText("text.heos.cannotUnregister", notNull(oldConfig.lang.cannotUnregister));
        Heos.langConfig.notAuthenticated = new TranslatableText("text.heos.notAuthenticated", notNull(oldConfig.lang.notAuthenticated));
        Heos.langConfig.alreadyAuthenticated = new TranslatableText("text.heos.alreadyAuthenticated", notNull(oldConfig.lang.alreadyAuthenticated));
        Heos.langConfig.successfullyAuthenticated = new TranslatableText("text.heos.successfullyAuthenticated", notNull(oldConfig.lang.successfullyAuthenticated));
        Heos.langConfig.successfulLogout = new TranslatableText("text.heos.successfulLogout", notNull(oldConfig.lang.successfulLogout));
        Heos.langConfig.timeExpired = new TranslatableText("text.heos.timeExpired", notNull(oldConfig.lang.timeExpired));
        Heos.langConfig.registerRequired = new TranslatableText("text.heos.registerRequired", notNull(oldConfig.lang.registerRequired));
        Heos.langConfig.alreadyRegistered = new TranslatableText("text.heos.alreadyRegistered", notNull(oldConfig.lang.alreadyRegistered));
        Heos.langConfig.registerSuccess = new TranslatableText("text.heos.registerSuccess", notNull(oldConfig.lang.registerSuccess));
        Heos.langConfig.userdataDeleted = new TranslatableText("text.heos.userdataDeleted", notNull(oldConfig.lang.userdataDeleted));
        Heos.langConfig.userdataUpdated = new TranslatableText("text.heos.userdataUpdated", notNull(oldConfig.lang.userdataUpdated));
        Heos.langConfig.accountDeleted = new TranslatableText("text.heos.accountDeleted", notNull(oldConfig.lang.accountDeleted));
        Heos.langConfig.configurationReloaded = new TranslatableText("text.heos.configurationReloaded", notNull(oldConfig.lang.configurationReloaded));
        Heos.langConfig.maxPasswordChars = new TranslatableText("text.heos.maxPasswordChars", notNull(oldConfig.lang.maxPasswordChars));
        Heos.langConfig.minPasswordChars = new TranslatableText("text.heos.minPasswordChars", notNull(oldConfig.lang.minPasswordChars));
        Heos.langConfig.disallowedUsername = new TranslatableText("text.heos.disallowedUsername", notNull(oldConfig.lang.disallowedUsername));
        Heos.langConfig.playerAlreadyOnline = new TranslatableText("text.heos.playerAlreadyOnline", notNull(oldConfig.lang.playerAlreadyOnline));
        Heos.langConfig.worldSpawnSet = new TranslatableText("text.heos.worldSpawnSet", notNull(oldConfig.lang.worldSpawnSet));
        Heos.langConfig.corruptedPlayerData = new TranslatableText("text.heos.corruptedPlayerData", notNull(oldConfig.lang.corruptedPlayerData));
        Heos.langConfig.userNotRegistered = new TranslatableText("text.heos.userNotRegistered", notNull(oldConfig.lang.userNotRegistered));
        Heos.langConfig.cannotLogout = new TranslatableText("text.heos.cannotLogout", notNull(oldConfig.lang.cannotLogout));
        Heos.langConfig.offlineUuid = new TranslatableText("text.heos.offlineUuid", notNull(oldConfig.lang.offlineUuid));
        Heos.langConfig.registeredPlayers = new TranslatableText("text.heos.registeredPlayers", notNull(oldConfig.lang.registeredPlayers));
        Heos.langConfig.save();

        Heos.technicalConfig = new TechnicalConfigV1();
        Heos.technicalConfig.globalPassword = notNull(oldConfig.main.globalPassword);
        Heos.technicalConfig.forcedOfflinePlayers = notNull(oldConfig.main.forcedOfflinePlayers);
        Heos.technicalConfig.confirmedOnlinePlayers = notNull(oldConfig.experimental.verifiedOnlinePlayer);
        Heos.technicalConfig.save();

        Heos.storageConfig = new StorageConfigV1();
        Heos.storageConfig.databaseType = notNull(oldConfig.main.databaseType);
        Heos.storageConfig.mysql.mysqlHost = notNull(oldConfig.main.MySQLHost);
        Heos.storageConfig.mysql.mysqlUser = notNull(oldConfig.main.MySQLUser);
        Heos.storageConfig.mysql.mysqlPassword = notNull(oldConfig.main.MySQLPassword);
        Heos.storageConfig.mysql.mysqlDatabase = notNull(oldConfig.main.MySQLDatabase);
        Heos.storageConfig.mysql.mysqlTable = notNull(oldConfig.main.MySQLTableName);
        Heos.storageConfig.mongodb.mongodbConnectionString = notNull(oldConfig.main.MongoDBConnectionString);
        Heos.storageConfig.mongodb.mongodbDatabase = notNull(oldConfig.main.MongoDBDatabase);
        Heos.storageConfig.save();
    }

    public static void migrateFromV1() {
        LogInfo("Migrating config and DB from v1 to v2");
        long now = System.currentTimeMillis();

        DbApi db;
        if (Heos.storageConfig.databaseType.equalsIgnoreCase("mysql")) {
            db = new MySQL(Heos.storageConfig);
        } else if (Heos.storageConfig.databaseType.equalsIgnoreCase("mongodb")) {
            db = new MongoDB(Heos.storageConfig);
        } else {
            Heos.storageConfig.databaseType = "sqlite";

            db = new SQLite(Heos.storageConfig);
        }
        try {
            db.connect();
        } catch (DBApiException e) {
            LogError("onInitialize error: ", e);
        }

        UserCache userCache = new UserCache(null, new File(gameDirectory + "/usercache.json"));
        HashMap<String, String> uuids = new HashMap<>();
        for (UserCache.Entry entry : userCache.load()) {
            //? if >= 1.21.9 {
            PlayerConfigEntry playerConfigEntry = entry.getPlayer();
            uuids.put(playerConfigEntry.name(), playerConfigEntry.id().toString());
            //?} else {
            /*GameProfile profile = entry.getProfile();
            uuids.put(profile.getName(), profile.getId().toString());
            *///?}
        }
        db.migrateFromV1(uuids);

        Heos.storageConfig.save();
        db.close();

        Heos.config.configVersion = 2;
        Heos.config.save();

        LogInfo("Migration completed in " + (System.currentTimeMillis() - now) + "ms");
    }

    public static void migrateFromV2() {
        LogInfo("Migrating config from v2 to v3");

        Heos.extendedConfig.save();
        Heos.langConfig.save();

        Heos.config.configVersion = 3;
        Heos.config.save();
    }
    
    private static String notNull(String string) {
        return string == null ? "" : string;
    }
    
    private static ArrayList<String> notNull(ArrayList<String> list) {
        return list == null ? new ArrayList<>() : list;
    }
}
