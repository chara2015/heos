package xyz.nikitacartes.heos.storage.database;

/**
 * Generic exception wrapping errors from DB
 */
public class DBApiException extends Exception {

    public DBApiException(String errorMessage, Exception e) {
        super("[Heos] " + errorMessage, e);
    }
}
