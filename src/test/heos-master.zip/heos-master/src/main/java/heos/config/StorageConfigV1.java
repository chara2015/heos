package xyz.nikitacartes.heos.config;

import org.spongepowered.configurate.objectmapping.ConfigSerializable;
import org.spongepowered.configurate.objectmapping.meta.Comment;

@ConfigSerializable
public class StorageConfigV1 extends ConfigTemplate {

    @Comment("""
            Database type. Can be sqlite, mysql or mongodb. SQLite is set by default.""")
    public String databaseType = "sqlite";

    @Comment("""
            
            SQLite configuration.""")
    public SQLiteConfig sqlite = new SQLiteConfig();

    @Comment("""
            
            MySQL configuration.""")
    public MySqlConfig mysql = new MySqlConfig();

    @Comment("""
            
            MongoDB configuration.""")
    public MongoDBConfig mongodb = new MongoDBConfig();

    public StorageConfigV1() {
        super("storage.conf", """
                ##                          ##
                ##         Heos         ##
                ##  Storage Configuration   ##
                ##                          ##
                
                Note: If your string contains special characters, you should enclose it in double quotes.""");
    }

    public static StorageConfigV1 create() {
        StorageConfigV1 config = loadConfig(StorageConfigV1.class, "storage.conf");
        if (config == null) {
            config = new StorageConfigV1();
            config.save();
        }
        return config;
    }

    public static StorageConfigV1 load() {
        StorageConfigV1 config = loadConfig(StorageConfigV1.class, "storage.conf");
        if (config == null) {
            throw new RuntimeException("Failed to load storage.conf");
        }
        return config;
    }

    @Override
    public void save() {
        save(StorageConfigV1.class, this);
    }

    @ConfigSerializable
    public static class MySqlConfig {
        @Comment("""
                
                MySQL host.""")
        public String mysqlHost = "localhost";

        @Comment("""
                
                MySQL user.""")
        public String mysqlUser = "root";

        @Comment("""
                
                MySQL password.""")
        public String mysqlPassword = "password";

        @Comment("""
                
                MySQL database.""")
        public String mysqlDatabase = "Heos";

        @Comment("""
                
                MySQL table name.""")
        public String mysqlTable = "Heos";
    }

    @ConfigSerializable
    public static class MongoDBConfig {
        @Comment("""
                
                MongoDB connection string.""")
        public String mongodbConnectionString = "mongodb://username:password@host:port/?options";

        @Comment("""
                
                MongoDB database name.""")
        public String mongodbDatabase = "Heos";
    }

    @ConfigSerializable
    public static class SQLiteConfig {
        @Comment("""
                
                SQLite database path.""")
        public String sqlitePath = "Heos/Heos.db";

        @Comment("""
                
                SQLite table name.""")
        public String sqliteTable = "Heos";
    }
}
