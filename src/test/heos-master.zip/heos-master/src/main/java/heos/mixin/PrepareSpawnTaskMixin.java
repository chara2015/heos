//? if >= 1.21.9 {
package xyz.nikitacartes.heos.mixin;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerConfigEntry;
import net.minecraft.server.network.PrepareSpawnTask;
import org.spongepowered.asm.mixin.*;
import xyz.nikitacartes.heos.interfaces.PrepareSpawnTaskInterface;
import xyz.nikitacartes.heos.utils.LastLocation;


@Mixin(PrepareSpawnTask.class)
public abstract class PrepareSpawnTaskMixin implements PrepareSpawnTaskInterface {

    @Unique
    private LastLocation Heos$spawnData = null;

    @Unique
    private boolean Heos$authenticated = false;

    @Final
    @Shadow
    PlayerConfigEntry player;

    @Final
    @Shadow
    MinecraftServer server;

    @Override
    public void Heos$setSpawnData(LastLocation spawnData) {
        this.Heos$spawnData = spawnData;
    }

    @Override
    public LastLocation Heos$getSpawnData() {
        return this.Heos$spawnData;
    }

    @Override
    public void Heos$setAuthenticated(boolean authenticated) {
        this.Heos$authenticated = authenticated;
    }

    @Override
    public boolean Heos$getAuthenticated() {
        return this.Heos$authenticated;
    }

    @Override
    public PlayerConfigEntry Heos$getPlayer() {
        return this.player;
    }

    @Override
    public MinecraftServer Heos$getServer() {
        return this.server;
    }
}
//?}