package xyz.nikitacartes.heos.integrations;

import me.drex.vanish.api.VanishAPI;
//? if != 1.20.2 || < 1.20 {
import me.drex.vanish.util.VanishedEntity;
//?}
import net.minecraft.server.network.ServerPlayerEntity;

import static xyz.nikitacartes.heos.Heos.technicalConfig;

public class VanishIntegration {
    public static boolean isVanished(ServerPlayerEntity player) {
        if (!technicalConfig.vanishLoaded) return false;
        return VanishAPI.isVanished(player);
    }

    public static void setVanished(ServerPlayerEntity player, boolean vanished) {
        if (!technicalConfig.vanishLoaded) return;
        VanishAPI.setVanish(player, vanished);
        //? if != 1.20.2 || < 1.20 {
        ((VanishedEntity) player).vanish$setDirty();
        //?}
    }
}
