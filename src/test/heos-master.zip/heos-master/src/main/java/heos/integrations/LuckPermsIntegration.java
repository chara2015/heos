package xyz.nikitacartes.heos.integrations;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.context.ContextCalculator;
import net.luckperms.api.context.ContextConsumer;
import net.luckperms.api.context.ContextSet;
import net.luckperms.api.context.ImmutableContextSet;
import net.minecraft.server.network.ServerPlayerEntity;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.jetbrains.annotations.NotNull;
import xyz.nikitacartes.heos.interfaces.PlayerAuth;

public class LuckPermsIntegration implements ContextCalculator<ServerPlayerEntity> {

    @Override
    public void calculate(@NonNull ServerPlayerEntity playerEntity, @NonNull ContextConsumer contextConsumer) {
        contextConsumer.accept("Heos:authenticated", Boolean.toString(((PlayerAuth)playerEntity).Heos$isAuthenticated()));
        contextConsumer.accept("Heos:online_account", Boolean.toString(((PlayerAuth)playerEntity).Heos$isUsingMojangAccount()));
    }

    @Override
    public @NotNull ContextSet estimatePotentialContexts() {
        ImmutableContextSet.Builder builder = ImmutableContextSet.builder();
        builder.add("Heos:authenticated", Boolean.toString(true));
        builder.add("Heos:online_account", Boolean.toString(true));

        builder.add("Heos:authenticated", Boolean.toString(false));
        builder.add("Heos:online_account", Boolean.toString(false));

        return builder.build();
    }

    public static void register() {
        LuckPerms luckPerms = LuckPermsProvider.get();
        luckPerms.getContextManager().registerCalculator(new LuckPermsIntegration());
    }

}
