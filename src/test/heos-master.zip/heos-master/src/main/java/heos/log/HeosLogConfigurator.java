package heos.log;

import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.plugins.util.PluginRegistry;
import org.apache.logging.log4j.core.util.Loader;

import java.io.IOException;
import java.net.URI;

public class HeosLogConfigurator implements PreLaunchEntrypoint {
    private static final Logger LOGGER = LogManager.getLogger("Heos Log");
    public static final long BUNDLE_ID = 54321;
    public static ClassLoader CLASSLOADER;

    @Override
    public void onPreLaunch() {
        LOGGER.info("Starting Log4j reconfiguration.");

        CLASSLOADER = Loader.getClassLoader();

        // Load our custom plugin
        loadPlugin();

        // Get the URI to the new config file
        URI newConfigUri = LogConfigFileHandler.getOrCreateDefaultConfigFile();

        // Attempt to reconfigure Log4j with the new config
        try {
            LogReconfigurator.reconfigureWithUri(newConfigUri);
        } catch (UnsupportedOperationException | IOException e) {
            LOGGER.error("Failed to reconfigure Log4j:", e);
            return;
        }

        LOGGER.info("Finished Log4j reconfiguration.");
    }

    public static void loadPlugin() {
        PluginRegistry.getInstance().loadFromBundle(BUNDLE_ID, CLASSLOADER);
    }
}

