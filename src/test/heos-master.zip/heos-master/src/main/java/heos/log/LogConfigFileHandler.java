package heos.log;

import net.fabricmc.loader.api.FabricLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;

public class LogConfigFileHandler {
    private static final Logger LOGGER = LogManager.getLogger("Heos Log");
    
    public static final String CONFIG_FILENAME = "heos_log4j_config.xml";
    public static final String FALLBACK_CONFIG_RESOURCE_PATH = "data/heos/fallback_log4j_config.xml";

    public static Path getDefaultConfigPath() {
        return FabricLoader.getInstance().getConfigDir().resolve(CONFIG_FILENAME);
    }

    public static URI getOrCreateDefaultConfigFile() {
        Path configPath = getDefaultConfigPath();
        if (!Files.exists(configPath)) {
            LOGGER.warn(
                    "Expected to find config file in default location '{}', but it does not exist! The fallback config will be written to this location to fix this.",
                    configPath);
            try {
                writeFallbackConfig(configPath);
            } catch (IOException e) {
                LOGGER.error(
                        "Could not write fallback config to the aforementioned location! The fallback config will be used directly for this session instead, but this error may happen again if the issue is not fixed:",
                        e);
            }
            return getFallbackConfigUri();
        }
        return configPath.toUri();
    }

    public static URI getFallbackConfigUri() {
        try {
            return HeosLogConfigurator.CLASSLOADER.getResource(FALLBACK_CONFIG_RESOURCE_PATH).toURI();
        } catch (URISyntaxException e) {
            LOGGER.error("Class loader returned an invalid URI! This should never happen:", e);
            throw new RuntimeException(e);
        }
    }

    public static InputStream getFallbackConfigBytes() {
        return HeosLogConfigurator.CLASSLOADER.getResourceAsStream(FALLBACK_CONFIG_RESOURCE_PATH);
    }

    public static void writeFallbackConfig(Path configPath) throws IOException {
        try (InputStream input = getFallbackConfigBytes()) {
            Files.copy(input, configPath);
        }
    }
}

