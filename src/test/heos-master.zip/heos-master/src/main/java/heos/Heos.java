package xyz.nikitacartes.heos;

import com.mojang.brigadier.tree.CommandNode;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import xyz.nikitacartes.heos.commands.*;
import xyz.nikitacartes.heos.config.*;
import xyz.nikitacartes.heos.storage.database.*;
import xyz.nikitacartes.heos.integrations.LuckPermsIntegration;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static xyz.nikitacartes.heos.config.ConfigMigration.migrateFromV1;
import static xyz.nikitacartes.heos.config.ConfigMigration.migrateFromV2;
import static xyz.nikitacartes.heos.utils.HeosLogger.*;

public class Heos {
    public static DbApi DB = null;

    public static final ExecutorService THREADPOOL = Executors.newCachedThreadPool();

    // Getting game directory
    public static Path gameDirectory;

    // Server properties
    public static final Properties serverProp = new Properties();

    public static MainConfigV1 config;
    public static ExtendedConfigV1 extendedConfig;
    public static LangConfigV1 langConfig;
    public static TechnicalConfigV1 technicalConfig;
    public static StorageConfigV1 storageConfig;


    public static void loadDatabase() {
        if (storageConfig.databaseType.equalsIgnoreCase("mysql")) {
            DB = new MySQL(storageConfig);
        } else if (storageConfig.databaseType.equalsIgnoreCase("mongodb")) {
            DB = new MongoDB(storageConfig);
        } else {
            DB = new SQLite(storageConfig);
        }
        try {
            DB.connect();
        } catch (DBApiException e) {
            LogError("Error while set up database connection", e);
        }
    }

    public static void migrateConfigs() {
        File file = new File(gameDirectory + "/config/Heos");
        if (!file.exists()) {
            if (!file.mkdirs()) {
                throw new RuntimeException("[Heos] Error creating directory for configs");
            }
            ConfigMigration.migrateFromV0();
        }
    }

    static void onStartServer(MinecraftServer server) {
        // Print Heos logo
        LOGGER.info("  _   _ _____    ___  ____  ");
        LOGGER.info(" | | | | ____|  / _ \\/ ___| ");
        LOGGER.info(" | |_| |  _|   | | | \\___ \\ ");
        LOGGER.info(" |  _  | |___  | |_| |___) |");
        LOGGER.info(" |_| |_|_____|  \\___/|____/ ");
        LOGGER.info("");
        
        if (DB.isClosed()) {
            LogError("Couldn't connect to database. Stopping server");
            server.stop(false);
        }

        // Register LuckPerms integration if it's loaded
        if (technicalConfig.luckPermsLoaded) {
            LuckPermsIntegration.register();
        }
    }

    static void onStopServer(MinecraftServer server) {
        LogInfo("Shutting down Heos.");

        // Closing threads
        try {
            THREADPOOL.shutdownNow();
            if (!THREADPOOL.awaitTermination(500, TimeUnit.MILLISECONDS)) {
                Thread.currentThread().interrupt();
            }
        } catch (InterruptedException e) {
            LogError("Error on stop", e);
            THREADPOOL.shutdownNow();
        }

        // Closing DbApi connection
        DB.close();
    }

    private static final int CURRENT_CONFIG_VERSION = 3;

    public static void loadConfigs() {
        int configVersion = VersionConfig.load().configVersion;

        if (configVersion == -1) {
            // Fresh install - create default configs
            Heos.config = MainConfigV1.create();
            Heos.technicalConfig = TechnicalConfigV1.create();
            Heos.langConfig = LangConfigV1.create();
            Heos.extendedConfig = ExtendedConfigV1.create();
            Heos.storageConfig = StorageConfigV1.create();
            return;
        }

        if (configVersion > CURRENT_CONFIG_VERSION) {
            LogError("Unknown config version: " + configVersion + "\n Using last known version");
        }

        // Load existing configs
        Heos.config = MainConfigV1.load();
        Heos.technicalConfig = TechnicalConfigV1.load();
        Heos.langConfig = LangConfigV1.load();
        Heos.extendedConfig = ExtendedConfigV1.load();
        Heos.storageConfig = StorageConfigV1.load();

        // Apply migrations sequentially
        if (configVersion < 2) {
            migrateFromV1();
        }
        if (configVersion < 3) {
            migrateFromV2();
        }
    }

    public static void saveConfigs() {
        Heos.config.save();
        Heos.technicalConfig.save();
        Heos.langConfig.save();
        Heos.extendedConfig.save();
        Heos.storageConfig.save();
    }

    public static void reloadConfigs(MinecraftServer server) {
        DB.close();

        boolean regAlias = extendedConfig.aliases.register;
        boolean loginAlias = extendedConfig.aliases.login;

        Heos.loadConfigs();

        try {
            DB.connect();
        } catch (DBApiException e) {
            LogError("onInitialize error: ", e);
        }

        CommandManager serverCommandManager = server.getCommandManager();
        try {
            Field literalsField = CommandNode.class.getDeclaredField("literals");
            literalsField.setAccessible(true);

            // noinspection unchecked
            Map<String, ?> literals = (Map<String, ?>) literalsField.get(serverCommandManager.getDispatcher().getRoot());
            literals.remove("register");
            literals.remove("login");
            if (regAlias) {
                literals.remove("reg");
            }
            if (loginAlias) {
                literals.remove("log");
            }

            CommandNode<ServerCommandSource> rootNode = serverCommandManager.getDispatcher().getRoot();

            rootNode.getChildren().removeIf(node ->
                    node.getName().equals("register") ||
                    node.getName().equals("login") ||
                    (regAlias && node.getName().equals("reg")) ||
                    (loginAlias && node.getName().equals("log")));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            LogError("Error while reloading commands: ", e);
            return;
        }

        RegisterCommand.registerCommand(serverCommandManager.getDispatcher());
        LoginCommand.registerCommand(serverCommandManager.getDispatcher());

        if (server.getPlayerManager() == null) {
            return;
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            serverCommandManager.sendCommandTree(player);
        }
    }

    public static ZonedDateTime getUnixZero() {
        return ZonedDateTime.of(1970, 1, 1, 0, 0, 0, 0, ZoneOffset.UTC);
    }
}
