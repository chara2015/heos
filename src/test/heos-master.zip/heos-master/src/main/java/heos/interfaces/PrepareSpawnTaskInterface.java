//? if >= 1.21.9 {
package xyz.nikitacartes.heos.interfaces;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerConfigEntry;
import xyz.nikitacartes.heos.utils.LastLocation;

public interface PrepareSpawnTaskInterface {
    // Temporary store spawn data until ServerPlayerEntity is created
    void Heos$setSpawnData(LastLocation spawnData);

    LastLocation Heos$getSpawnData();

    // Is that player authenticated?
    void Heos$setAuthenticated(boolean authenticated);

    boolean Heos$getAuthenticated();

    PlayerConfigEntry Heos$getPlayer();

    MinecraftServer Heos$getServer();
}
//?}