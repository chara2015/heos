package xyz.nikitacartes.heos.event;

import com.mojang.authlib.GameProfile;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
//? if >= 1.21.9 {
import net.minecraft.server.PlayerConfigEntry;
//?}
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerLoginNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Uuids;
//? if < 1.21.2 {
/*import net.minecraft.item.ItemStack;
import net.minecraft.util.TypedActionResult;
*///?}
import net.minecraft.util.math.BlockPos;
import xyz.nikitacartes.heos.integrations.VanishIntegration;
import xyz.nikitacartes.heos.storage.PlayerEntryV1;
import xyz.nikitacartes.heos.integrations.FloodgateApiHelper;
import xyz.nikitacartes.heos.interfaces.PlayerAuth;
import xyz.nikitacartes.heos.utils.PlayersCache;
import xyz.nikitacartes.heos.utils.StoneCutterUtils;

import java.net.SocketAddress;
import java.time.ZonedDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static xyz.nikitacartes.heos.Heos.*;
import static xyz.nikitacartes.heos.utils.HeosLogger.LogDebug;

/**
 * This class will take care of actions players try to do,
 * and cancel them if they aren't authenticated
 */
public class AuthEventHandler {

    public static long lastAcceptedPacket = 0;

    public static Pattern usernamePattern;
    /**
     * Player pre-join.
     * Returns text as a reason for disconnect or null to pass
     *
     * @param profile PlayerConfigEntry|GameProfile of the player
     * @param manager PlayerManager
     * @return Text if player should be disconnected
     */
    //? if >= 1.21.9 {
    public static Text checkCanPlayerJoinServer(PlayerConfigEntry profile, PlayerManager manager, SocketAddress socketAddress) {
    //?} else {
    /*public static Text checkCanPlayerJoinServer(GameProfile profile, PlayerManager manager, SocketAddress socketAddress) {
    *///?}
        // Getting the player. By this point, the player's game profile has been authenticated so the UUID is legitimate.
        String incomingPlayerUsername = StoneCutterUtils.getName(profile);
        PlayerEntity onlinePlayer = manager.getPlayer(incomingPlayerUsername);

        if ((onlinePlayer != null) && ((PlayerAuth) onlinePlayer).Heos$isAuthenticated() && extendedConfig.preventAnotherLocationKick) {
            // Player needs to be kicked, since there's already a player with that name
            // playing on the server

            // if joining from same IP, allow the player to join
            String string = socketAddress.toString();
            if (string.contains("/")) {
                string = string.substring(string.indexOf(47) + 1);
            }

            if (string.contains(":")) {
                string = string.substring(0, string.indexOf(58));
            }

            if (!((PlayerAuth) onlinePlayer).Heos$getIpAddress().equals(string)) {
                return langConfig.playerAlreadyOnline.getNonTranslatable(incomingPlayerUsername);
            }
        }

        // Checking if player username is valid. The pattern is generated when the config is (re)loaded.
        Matcher matcher = usernamePattern.matcher(incomingPlayerUsername);

        if (!(matcher.matches() || (extendedConfig.floodgateBypassRegex && FloodgateApiHelper.isFloodgatePlayer(StoneCutterUtils.getId(profile))))) {
            return langConfig.disallowedUsername.getNonTranslatable(extendedConfig.usernameRegexp);
        }
        // If the player name and registered name are different, kick the player if differentUsernameCase is enabled
        // Create in case of Floodgate player
        PlayerEntryV1 playerEntryV1 = PlayersCache.getOrLoadOrRegister(incomingPlayerUsername);

        if (!extendedConfig.allowCaseInsensitiveUsername && !playerEntryV1.username.equals(incomingPlayerUsername)) {
            return langConfig.differentUsernameCase.getNonTranslatable(incomingPlayerUsername);
        }

        if (config.maxLoginTries != -1 && playerEntryV1.lastKickedDate.plusSeconds(config.resetLoginAttemptsTimeout).isAfter(ZonedDateTime.now())) {
            return langConfig.loginTriesExceeded.getNonTranslatable();
        }

        return null;
    }

    public static void loadPlayerData(ServerPlayerEntity player, ClientConnection connection) {
        PlayerAuth playerAuth = (PlayerAuth) player;

        // Create in case of Carpet player
        String username = StoneCutterUtils.getUsername(player);
        PlayerEntryV1 cache = PlayersCache.getOrCreate(username);
        boolean update = false;
        if (cache.uuid == null) {
            cache.uuid = player.getUuid();
            update = true;
        }
        playerAuth.Heos$setPlayerEntryV1(cache);

        playerAuth.Heos$setIpAddress(connection);
        playerAuth.Heos$setSkipAuth();

        if (config.vanishUntilAuth) {
            ((PlayerAuth) player).Heos$wasVanished(VanishIntegration.isVanished(player));
        }

        if (playerAuth.Heos$canSkipAuth()) {
            playerAuth.Heos$setAuthenticated(true);

            update = false;
        } else if (cache.lastIp.equals(playerAuth.Heos$getIpAddress()) && cache.lastAuthenticatedDate.plusSeconds(config.sessionTimeout).isAfter(ZonedDateTime.now())) {
            playerAuth.Heos$setAuthenticated(true);

            cache.lastAuthenticatedDate = ZonedDateTime.now();
            update = true;
        }

        if (update) {
            cache.update();
        }

        if (extendedConfig.skipAllAuthChecks) {
            playerAuth.Heos$setAuthenticated(true);
        }

        if (config.vanishUntilAuth && !playerAuth.Heos$isAuthenticated()) {
            VanishIntegration.setVanished(player, true);
        }
    }

    // Player joining the server
    public static void onPlayerJoin(ServerPlayerEntity player) {
        PlayerAuth playerAuth = (PlayerAuth) player;

        if (playerAuth.Heos$canSkipAuth()) {
            langConfig.onlinePlayerLogin.send(player);
            return;
        } else if (playerAuth.Heos$isAuthenticated()) {
            langConfig.validSession.send(player);
            return;
        } else if (extendedConfig.skipAllAuthChecks) {
            return;
        }

        // Tries to rescue player from nether portal
        if (extendedConfig.tryPortalRescue) {
            BlockPos pos = player.getBlockPos();
            player.teleport(pos.getX() + 0.5, player.getY(), pos.getZ() + 0.5, false);
            if (player.getBlockStateAtPos().getBlock().equals(Blocks.NETHER_PORTAL) || StoneCutterUtils.getServerWorld(player).getBlockState(player.getBlockPos().up()).getBlock().equals(Blocks.NETHER_PORTAL)) {
                // Faking portal blocks to be air
                BlockUpdateS2CPacket feetPacket = new BlockUpdateS2CPacket(pos, Blocks.AIR.getDefaultState());
                player.networkHandler.sendPacket(feetPacket);

                BlockUpdateS2CPacket headPacket = new BlockUpdateS2CPacket(pos.up(), Blocks.AIR.getDefaultState());
                player.networkHandler.sendPacket(headPacket);
            }
        }
    }

    public static void onPlayerLeave(ServerPlayerEntity player) {
        PlayerAuth playerAuth = (PlayerAuth) player;
        if (playerAuth.Heos$canSkipAuth())
            return;

        if (playerAuth.Heos$isAuthenticated()) {
            PlayerEntryV1 playerCache = playerAuth.Heos$getPlayerEntryV1();
            playerCache.lastAuthenticatedDate = ZonedDateTime.now();
            playerCache.update();
            return;
        }
        if (config.hidePlayerCoords) {
            ((PlayerAuth) player).Heos$restoreTrueLocation();
        }
    }

    // Player execute command
    public static ActionResult onPlayerCommand(ServerPlayerEntity player, String command) {
        // Getting the message to then be able to check it
        if (extendedConfig.allowCommands) {
            return ActionResult.PASS;
        }
        if (player == null) {
            return ActionResult.PASS;
        }
        if (command.startsWith("login ")
                || command.startsWith("register ")
                || (extendedConfig.aliases.login && command.startsWith("l "))
                || (extendedConfig.aliases.register && command.startsWith("reg "))) {
            return ActionResult.PASS;
        }
        if (!((PlayerAuth) player).Heos$isAuthenticated()) {
            String username = StoneCutterUtils.getUsername(player);
            for (String allowedCommand : extendedConfig.allowedCommands) {
                if (command.startsWith(allowedCommand)) {
                    LogDebug("Player " + username + " executed command " + command + " without being authenticated.");
                    return ActionResult.PASS;
                }
            }
            LogDebug("Player " + username + " tried to execute command " + command + " without being authenticated.");
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }
        return ActionResult.PASS;
    }

    // Player chatting
    public static ActionResult onPlayerChat(ServerPlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowChat) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }
        return ActionResult.PASS;
    }

    // Player movement
    public static ActionResult onPlayerMove(ServerPlayerEntity player) {
        // Player will fall if enabled (prevent fly kick)
        // Otherwise, movement should be disabled
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowMovement) {
            if (System.nanoTime() >= lastAcceptedPacket + extendedConfig.teleportationTimeoutMs * 1000000) {
                player.networkHandler.requestTeleport(player.getX(), player.getY(), player.getZ(), player.getYaw(), player.getPitch());
                lastAcceptedPacket = System.nanoTime();
            }
            return ActionResult.FAIL;
        }
        return ActionResult.PASS;
    }

    // Using a block (right-click function)
    public static ActionResult onUseBlock(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowBlockInteraction) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }
        return ActionResult.PASS;
    }

    // Breaking a block
    public static boolean onBreakBlock(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowBlockBreaking) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return false;
        }
        return true;
    }

    // Using an item
    //? if >= 1.21.2 {
    public static ActionResult onUseItem(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowItemUsing) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }

        return ActionResult.PASS;
    }
    //?} else {
    /*public static TypedActionResult<ItemStack> onUseItem(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowItemUsing) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return TypedActionResult.fail(ItemStack.EMPTY);
        }

        return TypedActionResult.pass(ItemStack.EMPTY);
    }
    *///?}

    // Dropping an item
    public static ActionResult onDropItem(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowItemDropping) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }
        return ActionResult.PASS;
    }

    // Changing inventory (item moving etc.)
    public static ActionResult onTakeItem(ServerPlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowItemMoving) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }

        return ActionResult.PASS;
    }

    // Attacking an entity
    public static ActionResult onAttackEntity(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowEntityAttacking) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }

        return ActionResult.PASS;
    }

    // Interacting with entity
    public static ActionResult onUseEntity(PlayerEntity player) {
        if (!((PlayerAuth) player).Heos$isAuthenticated() && !extendedConfig.allowEntityInteraction) {
            ((PlayerAuth) player).Heos$sendAuthMessage();
            return ActionResult.FAIL;
        }

        return ActionResult.PASS;
    }

    public static void onPreLogin(ServerLoginNetworkHandler netHandler) {
        if (extendedConfig.forcedOfflineUuid && netHandler.profile != null) {
            //? if >= 1.21.9 {
            netHandler.profile = Uuids.getOfflinePlayerProfile(netHandler.profile.name());
            //?} else if >= 1.20.3 {
            //netHandler.profile = Uuids.getOfflinePlayerProfile(netHandler.profile.getName());
            //?} else if >= 1.20.2 {
            /*netHandler.profile = ServerLoginNetworkHandler.createOfflineProfile(netHandler.profile.getName());
            *///?} else {
            /*netHandler.profile = netHandler.toOfflineProfile(netHandler.profile);
            *///?}
        }
    }

}
