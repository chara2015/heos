package xyz.nikitacartes.heos.mixin;

import com.google.common.net.InetAddresses;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.ClientConnection;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
//? if >= 1.21.6 {
import net.minecraft.storage.ReadView;
//?}
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xyz.nikitacartes.heos.event.AuthEventHandler;
import xyz.nikitacartes.heos.integrations.FloodgateApiHelper;
import xyz.nikitacartes.heos.integrations.VanishIntegration;
import xyz.nikitacartes.heos.interfaces.PlayerAuth;
import xyz.nikitacartes.heos.storage.PlayerEntryV1;
import xyz.nikitacartes.heos.utils.*;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.UUID;

import static xyz.nikitacartes.heos.Heos.*;
import static xyz.nikitacartes.heos.utils.HeosLogger.LogDebug;
import static xyz.nikitacartes.heos.utils.StoneCutterUtils.*;

@Mixin(ServerPlayerEntity.class)
public abstract class ServerPlayerEntityMixin extends EntityMixin implements PlayerAuth {
    @Unique
    private final ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

    @Final
    @Shadow
    //? if >= 1.21.6 {
    private MinecraftServer server;
    //?} else {
    /*public MinecraftServer server;
    *///?}

    @Unique
    private long kickTimer = config.kickTimeout * 20;

    @Unique
    private String ipAddress = null;

    @Unique
    private LastLocation lastLocation = null;

    @Unique
    private UUID ridingEntityUUID = null;

    @Unique
    //? if >= 1.21.6 {
    private ReadView rootVehicle = null;
    //?} else {
    /*private NbtCompound rootVehicle = null;
    *///?}

    @Unique
    private boolean wasDead = false;

    @Unique
    PlayerEntryV1 playerEntryV1 = new PlayerEntryV1(getUsername(player));

    @Unique
    private boolean canSkipAuth = this.player.getClass() != ServerPlayerEntity.class;

    @Unique
    private boolean isAuthenticated = this.player.getClass() != ServerPlayerEntity.class;

    @Unique
    private boolean isUsingMojangAccount = false;

    @Unique
    private boolean wasVanished = false;

    //? if >= 1.21.9 {
    @Override
    public void Heos$savePlayerInfo() {
        ridingEntityUUID = player.getVehicle() != null ? player.getVehicle().getUuid() : null;
        wasDead = player.isDead();
        String username = player.getNameForScoreboard();
        if (ridingEntityUUID != null) {
            LogDebug(String.format("Saving vehicle of player %s as %s", username, ridingEntityUUID));
        }
    }
    //?}

    @Override
    public void Heos$saveTrueLocation() {
        if (lastLocation == null) {
            lastLocation = new LastLocation();
        }
        lastLocation.position = getPosition(player);
        lastLocation.yaw = player.getYaw();
        lastLocation.pitch = player.getPitch();

        ridingEntityUUID = player.getVehicle() != null ? player.getVehicle().getUuid() : null;
        wasDead = player.isDead();
        String username = getUsername(player);
        LogDebug(String.format("Saving position of player %s as %s", username, lastLocation));
        if (ridingEntityUUID != null) {
            LogDebug(String.format("Saving vehicle of player %s as %s", username, ridingEntityUUID));
        }
    }

    @Override
    public void Heos$saveTrueDimension(RegistryKey<World> registryKey) {
        if (lastLocation == null) {
            lastLocation = new LastLocation();
        }
        lastLocation.dimension = registryKey;
    }

    @Override
    public void Heos$restoreTrueLocation() {
        if (lastLocation == null) {
            return;
        }
        if (wasDead) {
            StoneCutterUtils.killPlayer(player);
            return;
        }
        // Puts player to last saved position
        teleport(player, lastLocation, server.getWorld(World.OVERWORLD));
        String username = getUsername(player);
        LogDebug(String.format("Teleported player %s to %s", username, lastLocation));

        if (rootVehicle != null) {
            LogDebug(String.format("Mounting player to vehicle %s", rootVehicle));
            readRootVehicle(player, rootVehicle);
        }

        if (player.getVehicle() == null && ridingEntityUUID != null) {
            LogDebug(String.format("Mounting player to vehicle %s", ridingEntityUUID));
            if (lastLocation.dimension == null) return;
            ServerWorld world = server.getWorld(lastLocation.dimension);
            if (world == null) return;
            Entity entity = world.getEntity(ridingEntityUUID);
            if (entity != null) {
                startRiding(player, entity);
            } else {
                LogDebug("Could not find vehicle for player " + username);
            }
        }
    }

    /**
     * Gets the text which tells the player
     * to login or register, depending on account status.
     *
     */
    @Override
    public void Heos$sendAuthMessage() {
        if (playerEntryV1 != null && !playerEntryV1.password.isEmpty()) {
            langConfig.loginRequired.send(player);
            return;
        }
        if (!config.enableGlobalPassword) {
            langConfig.registerRequired.send(player);
            return;
        }
        if (config.singleUseGlobalPassword) {
            langConfig.registerRequiredWithGlobalPassword.send(player);
            return;
        }
        langConfig.loginRequired.send(player);
    }

    /**
     * Checks whether player can skip an authentication process (Online Player or Fake one).
     *
     * @return true if a player can skip an authentication process, otherwise false
     */
    @Override
    public boolean Heos$canSkipAuth() {
        return canSkipAuth;
    }

    @Override
    public void Heos$setSkipAuth() {
        Heos$setUsingMojangAccount();
        canSkipAuth = (this.player.getClass() != ServerPlayerEntity.class) ||
                (config.floodgateAutoLogin && FloodgateApiHelper.isFloodgatePlayer(this.player)) ||
                (config.premiumAutoLogin && Heos$isUsingMojangAccount());
    }

    /**
     * Whether the player is using the mojang account.
     *
     * @return true if they are  using mojang account, otherwise false
     */
    @Override
    public boolean Heos$isUsingMojangAccount() {
        return isUsingMojangAccount;
    }

    @Override
    public void Heos$setUsingMojangAccount() {
        isUsingMojangAccount = server.isOnlineMode() && playerEntryV1.onlineAccount == PlayerEntryV1.OnlineAccount.TRUE;
    }

    /**
     * Checks whether player is authenticated.
     *
     * @return false if player is not authenticated, otherwise true.
     */
    @Override
    public boolean Heos$isAuthenticated() {
        return isAuthenticated;
    }

    /**
     * Sets the authentication status of the player
     *
     * @param authenticated whether player should be authenticated
     */
    @Override
    public void Heos$setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;

        if (authenticated) {
            kickTimer = config.kickTimeout * 20;
            // Updating blocks if needed (in case if portal rescue action happened)
            World world = StoneCutterUtils.getServerWorld(player);
            BlockPos pos = player.getBlockPos();

            // Sending updates to portal blocks
            // This is technically not needed, but it cleans the "messed portal" on the client
            if (world.isInBuildLimit(pos)) {
                world.updateListeners(pos, world.getBlockState(pos), world.getBlockState(pos), 3);
            }
            if (world.isInBuildLimit(pos.up())) {
                world.updateListeners(pos.up(), world.getBlockState(pos.up()), world.getBlockState(pos.up()), 3);
            }

            player.currentScreenHandler.syncState();

            VanishIntegration.setVanished(player, wasVanished);
        } else {
            if (config.vanishUntilAuth) {
                wasVanished = VanishIntegration.isVanished(player);
                VanishIntegration.setVanished(player, true);
            }
        }
    }

    @Inject(method = "playerTick()V", at = @At("HEAD"), cancellable = true)
    private void playerTick(CallbackInfo ci) {
        if (!this.Heos$isAuthenticated()) {
            // Checking player timer
            if (kickTimer <= 0 && player.networkHandler.isConnectionOpen()) {
                player.networkHandler.disconnect(langConfig.timeExpired.get());
            } else {
                // Sending authentication prompt every 10 seconds
                if (kickTimer % (extendedConfig.authenticationPromptInterval * 20) == 0) {
                    this.Heos$sendAuthMessage();
                }
                --kickTimer;
            }
            ci.cancel();
        }
    }

    // Player item dropping
    //? if >= 1.21.11 {
    @Inject(method = "dropSelectedItem(Z)V", at = @At("HEAD"), cancellable = true)
    private void dropSelectedItem(boolean entireStack, CallbackInfo ci) {
        ActionResult result = AuthEventHandler.onDropItem(player);

        if (result == ActionResult.FAIL) {
            ci.cancel();
        }
    }
    //?} else {
    /*@Inject(method = "dropSelectedItem(Z)Z", at = @At("HEAD"), cancellable = true)
    private void dropSelectedItem(boolean dropEntireStack, CallbackInfoReturnable<Boolean> cir) {
        ActionResult result = AuthEventHandler.onDropItem(player);

        if (result == ActionResult.FAIL) {
            cir.setReturnValue(false);
        }
    }
    *///?}

    @Inject(method = "copyFrom(Lnet/minecraft/server/network/ServerPlayerEntity;Z)V", at = @At("RETURN"))
    private void copyFrom(ServerPlayerEntity oldPlayer, boolean alive, CallbackInfo ci) {
        PlayerAuth oldPlayerAuth = (PlayerAuth) oldPlayer;
        PlayerAuth newPlayerAuth = (PlayerAuth) player;
        newPlayerAuth.Heos$setKickTimer(oldPlayerAuth.Heos$getKickTimer());
        newPlayerAuth.Heos$setIpAddress(oldPlayerAuth.Heos$getIpAddress());
        newPlayerAuth.Heos$setLastLocation(oldPlayerAuth.Heos$getLastLocation());
        newPlayerAuth.Heos$setRidingEntityUUID(oldPlayerAuth.Heos$getRidingEntityUUID());
        newPlayerAuth.Heos$setRootVehicle(oldPlayerAuth.Heos$getRootVehicle());
        newPlayerAuth.Heos$wasDead(oldPlayerAuth.Heos$wasDead());
        newPlayerAuth.Heos$canSkipAuth(oldPlayerAuth.Heos$canSkipAuth());
        newPlayerAuth.Heos$setAuthenticated(oldPlayerAuth.Heos$isAuthenticated());

        newPlayerAuth.Heos$setPlayerEntryV1(oldPlayerAuth.Heos$getPlayerEntryV1());
    }

    @Override
    public boolean Heos$isInvisible(boolean original) {
        return original || (!isAuthenticated && extendedConfig.playerIgnored);
    }

    @Override
    public boolean Heos$isInvulnerable(boolean original) {
        return original || (!isAuthenticated && extendedConfig.playerInvulnerable);
    }

    public long Heos$getKickTimer() {
        return kickTimer;
    }

    public void Heos$setKickTimer(long kickTimer) {
        this.kickTimer = kickTimer;
    }

    public void Heos$setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public LastLocation Heos$getLastLocation() {
        return lastLocation;
    }

    public void Heos$setLastLocation(LastLocation lastLocation) {
        this.lastLocation = lastLocation;
    }

    public UUID Heos$getRidingEntityUUID() {
        return ridingEntityUUID;
    }

    public void Heos$setRidingEntityUUID(UUID ridingEntityUUID) {
        this.ridingEntityUUID = ridingEntityUUID;
    }

    //? if >= 1.21.6 {
    public ReadView Heos$getRootVehicle() {
        return rootVehicle;
    }

    public void Heos$setRootVehicle(ReadView rootVehicle) {
        this.rootVehicle = rootVehicle;
    }
    //?} else {
    /*public NbtCompound Heos$getRootVehicle() {
        return rootVehicle;
    }

    public void Heos$setRootVehicle(NbtCompound rootVehicle) {
        this.rootVehicle = rootVehicle;
    }
    *///?}

    public boolean Heos$wasDead() {
        return wasDead;
    }

    public void Heos$wasDead(boolean wasDead) {
        this.wasDead = wasDead;
    }

    public void Heos$canSkipAuth(boolean cantSkipAuth) {
        this.canSkipAuth = cantSkipAuth;
    }

    public String Heos$getIpAddress() {
        return ipAddress;
    }

    public void Heos$setIpAddress(ClientConnection connection) {
        SocketAddress socketAddress = connection.getAddress();
        ipAddress = socketAddress instanceof InetSocketAddress inetSocketAddress ? InetAddresses.toAddrString(inetSocketAddress.getAddress()) : "<unknown>";
    }

    public PlayerEntryV1 Heos$getPlayerEntryV1() {
        return playerEntryV1;
    }

    public void Heos$setPlayerEntryV1(PlayerEntryV1 playerEntryV1) {
        this.playerEntryV1 = playerEntryV1;
    }

    public boolean Heos$wasVanished() {
        return wasVanished;
    }

    public void Heos$wasVanished(boolean wasVanished) {
        this.wasVanished = wasVanished;
    }

}

