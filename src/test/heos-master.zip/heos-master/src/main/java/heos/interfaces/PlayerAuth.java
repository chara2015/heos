package xyz.nikitacartes.heos.interfaces;

//? if >= 1.21.6 {
import net.minecraft.storage.ReadView;
//?}
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.ClientConnection;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;
import xyz.nikitacartes.heos.storage.PlayerEntryV1;
import xyz.nikitacartes.heos.utils.LastLocation;

import java.util.UUID;

/**
 * PLayer authentication extension.
 */
public interface PlayerAuth {
    void Heos$savePlayerInfo();

    void Heos$saveTrueLocation();

    void Heos$saveTrueDimension(RegistryKey<World> registryKey);

    void Heos$restoreTrueLocation();

    /**
     * Sets the authentication status of the player.
     *
     * @param authenticated whether player should be authenticated
     * @see <a href="https://samolego.github.io/SimpleAuth/org/samo_lego/simpleauth/mixin/MixinPlayerEntity.html">See implementation</a>
     */
    void Heos$setAuthenticated(boolean authenticated);

    /**
     * Checks whether player is authenticated.
     *
     * @return false if player is not authenticated, otherwise true.
     * @see <a href="https://samolego.github.io/SimpleAuth/org/samo_lego/simpleauth/mixin/MixinPlayerEntity.html">See implementation</a>
     */
    boolean Heos$isAuthenticated();

    /**
     * Gets the text which tells the player
     * to login or register, depending on account status.
     *
     * @return Text with appropriate string (login or register)
     * @see <a href="https://samolego.github.io/SimpleAuth/org/samo_lego/simpleauth/mixin/MixinPlayerEntity.html">See implementation</a>
     */
    void Heos$sendAuthMessage();

    /**
     * Checks whether player can skip an authentication process (Online Player or Fake one).
     *
     * @return true if player is fake (can skip authentication process), otherwise false
     * @see <a href="https://samolego.github.io/SimpleAuth/org/samo_lego/simpleauth/mixin/MixinPlayerEntity.html">See implementation</a>
     */
    boolean Heos$canSkipAuth();

    void Heos$setSkipAuth();

    /**
     * Whether the player is using the mojang account
     *
     * @return true if paid, false if cracked
     */
    boolean Heos$isUsingMojangAccount();

    void Heos$setUsingMojangAccount();
    /**
     * Gets the player's IP address on connection step.
     *
     * @return player's IP address as string
     */
    String Heos$getIpAddress();

    /**
     * Sets the player's IP address on connection step.
     *
     * @param ClientConnection connection
     */
    void Heos$setIpAddress(ClientConnection connection);

    PlayerEntryV1 Heos$getPlayerEntryV1();
    void Heos$setPlayerEntryV1(PlayerEntryV1 playerEntryV1);
    void Heos$canSkipAuth(boolean cantSkipAuth);
    long Heos$getKickTimer();
    void Heos$setKickTimer(long kickTimer);
    void Heos$setIpAddress(String ipAddress);
    LastLocation Heos$getLastLocation();
    void Heos$setLastLocation(LastLocation lastLocation);
    //? if >= 1.21.6 {
    ReadView Heos$getRootVehicle();
    void Heos$setRootVehicle(ReadView rootVehicle);
    //?} else {
    /*NbtCompound Heos$getRootVehicle();
    void Heos$setRootVehicle(NbtCompound rootVehicle);
    *///?}
    UUID Heos$getRidingEntityUUID();
    void Heos$setRidingEntityUUID(UUID ridingEntityUUID);
    boolean Heos$wasDead();
    void Heos$wasDead(boolean wasDead);
    boolean Heos$wasVanished();
    void Heos$wasVanished(boolean wasVanished);
}
